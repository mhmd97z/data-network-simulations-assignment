# Importing the network class, file names may be subject to change.
from p2p_new import Network
import time

# Initialize the constructor lists
node_ID_1 = 1
node_ID_2 = 2
node_ID_3 = 3
node_ID_4 = 4 
node_ID_5 = 5
node_ID_6 = 6
node_ID_7 = 7
node_ID_8 = 8 
node_ID_9 = 9
node_ID_10 = 10


# Node 1
neighbor_nodes_1 = [4] 
link_delays_1 = [0.1]
file_list_1 = ["first.txt"]

# Node 2
neighbor_nodes_2 = [3, 4] 
link_delays_2 = [0.1, 0.3]
file_list_2 = ["second.txt"]

# Node 3
neighbor_nodes_3 = [2, 4] 
link_delays_3 = [0.1, 0.2]
file_list_3 = ["third.txt"]

# Node 4
neighbor_nodes_4 = [1, 2, 3, 5, 6, 7] 
link_delays_4 = [0.1, 0.3, 0.2, 0.2, 0.15, 0.1]
file_list_4 = ["fourth.txt"]

# Node 5
neighbor_nodes_5 = [4, 6, 8] 
link_delays_5 = [0.2, 0.15, 0.2]
file_list_5 = ["fifth.txt"]

# Node 6
neighbor_nodes_6 = [4, 5, 7, 9] 
link_delays_6 = [0.15, 0.15, 0.21, 0.12]
file_list_6 = ["sixth.txt"]

# Node 7
neighbor_nodes_7 = [4, 6, 9] 
link_delays_7 = [0.1, 0.21, 0.17]
file_list_7 = ["seventh.txt"]

# Node 8
neighbor_nodes_8 = [5, 9, 10] 
link_delays_8 = [0.2, 0.3, 0.4]
file_list_8 = ["eighth.txt"]

# Node 9
neighbor_nodes_9 = [6, 7, 8, 10] 
link_delays_9 = [0.12, 0.17, 0.3, 0.1]
file_list_9 = ["nineth.txt"]

# Node 10
neighbor_nodes_10 = [8, 9] 
link_delays_10 = [0.4, 0.1]
file_list_10 = ["tenth.txt"]


graph_topology = [[node_ID_1, "127.0.0.1", 4000, neighbor_nodes_1, link_delays_1, file_list_1], 
                  [node_ID_2, "127.0.0.1", 4008, neighbor_nodes_2, link_delays_2, file_list_2], 
                  [node_ID_3, "127.0.0.1", 4016, neighbor_nodes_3, link_delays_3, file_list_3], 
                  [node_ID_4, "127.0.0.1", 4032, neighbor_nodes_4, link_delays_4, file_list_4],
	 [node_ID_5, "127.0.0.1", 4064, neighbor_nodes_5, link_delays_5, file_list_5],
	 [node_ID_6, "127.0.0.1", 4128, neighbor_nodes_6, link_delays_6, file_list_6],
	 [node_ID_7, "127.0.0.1", 4256, neighbor_nodes_7, link_delays_7, file_list_7],
	 [node_ID_8, "127.0.0.1", 4384, neighbor_nodes_8, link_delays_8, file_list_8],
	 [node_ID_9, "127.0.0.1", 4512, neighbor_nodes_9, link_delays_9, file_list_9],
	 [node_ID_10, "127.0.0.1", 4640, neighbor_nodes_10, link_delays_10, file_list_10]]


# Create the network 
net = Network(graph_topology)

# Execute the functions
DELAY = 5

net.init_network()
time.sleep(DELAY)
print('####### INIT DONE #######')

net.file_request(3, "fifth.txt")
time.sleep(DELAY)
print('####### FREQ DONE #######')


net.file_request(1, "fourth.txt")
time.sleep(DELAY)
print('####### FREQ DONE #######')

net.file_request(1, "seventh.txt")
time.sleep(DELAY)
print('####### FREQ DONE #######')

net.delete_node(4)
time.sleep(DELAY)
print('####### FDEL DONE #######')

net.file_request(1, "third.txt")
time.sleep(DELAY)
print('####### FREQ DONE #######')

net.add_node(4, "127.0.0.1", 4032, [1, 2, 3, 5, 6, 7], ["127.0.0.1", "127.0.0.1", "127.0.0.1", "127.0.0.1", "127.0.0.1", "127.0.0.1"], [4000, 4008, 4016, 4064, 4128, 4256], [0.1, 0.3, 0.2, 0.2, 0.15, 0.1], ["fourth.txt"])
time.sleep(DELAY)
print('####### FADD DONE #######')

net.file_request(1, "second.txt")
time.sleep(DELAY)
print('####### FREQ DONE #######')

net.file_request(6, "eighth.txt")
time.sleep(DELAY)
print('####### FREQ DONE #######')

net.delete_node(5)
time.sleep(DELAY)
print('####### FDEL DONE #######')

net.file_request(7, "nineth.txt")
time.sleep(DELAY)
print('####### FREQ DONE #######')
